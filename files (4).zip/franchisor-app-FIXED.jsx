import React, { useState, useEffect } from 'react';
import { 
  Home, Store, Settings, MessageSquare, Package, TrendingUp, TrendingDown,
  MapPin, Camera, FileText, ShoppingCart, AlertCircle, Calendar, Video,
  Users, DollarSign, BarChart3, Bell, Search, Filter, ChevronRight,
  Phone, Mail, Clock, CheckCircle, XCircle, Plus, Send, Menu, X
} from 'lucide-react';

const FranchisorApp = () => {
  const [activeMenu, setActiveMenu] = useState('beranda');
  const [selectedOutlet, setSelectedOutlet] = useState(null);
  const [showCCTV, setShowCCTV] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [userRole, setUserRole] = useState('franchisor');
  const [notifications, setNotifications] = useState(3);
  const [showMenu, setShowMenu] = useState(false);

  // Sample data
  const outlets = [
    {
      id: 1,
      name: 'Gerai Sudirman',
      owner: 'Ahmad Wijaya',
      location: { lat: -6.2088, lng: 106.8456 },
      address: 'Jl. Sudirman No. 45, Jakarta Pusat',
      status: 'sehat',
      revenue: 45000000,
      growth: 12.5,
      lastOrder: '2 jam lalu',
      healthScore: 95,
      complaints: 1
    },
    {
      id: 2,
      name: 'Gerai Kelapa Gading',
      owner: 'Siti Nurhaliza',
      location: { lat: -6.1570, lng: 106.9050 },
      address: 'Mall Kelapa Gading Lt. 3, Jakarta Utara',
      status: 'perlu perhatian',
      revenue: 38000000,
      growth: -5.2,
      lastOrder: '1 hari lalu',
      healthScore: 72,
      complaints: 3
    },
    {
      id: 3,
      name: 'Gerai BSD',
      owner: 'Budi Santoso',
      location: { lat: -6.3018, lng: 106.6519 },
      address: 'BSD City Walk, Tangerang Selatan',
      status: 'sehat',
      revenue: 52000000,
      growth: 18.3,
      lastOrder: '30 menit lalu',
      healthScore: 98,
      complaints: 0
    },
    {
      id: 4,
      name: 'Gerai Depok',
      owner: 'Linda Kusuma',
      location: { lat: -6.4025, lng: 106.7942 },
      address: 'Margonda Raya No. 88, Depok',
      status: 'sehat',
      revenue: 41000000,
      growth: 8.7,
      lastOrder: '4 jam lalu',
      healthScore: 88,
      complaints: 1
    }
  ];

  const financialSummary = {
    totalRevenue: 176000000,
    totalOrders: 1247,
    growth: 11.2,
    date: '1-12 Februari 2026',
    grossRevenue: 176000000,
    expenses: 89000000,
    netProfit: 87000000
  };

  const agendas = [
    { id: 1, title: 'Pelatihan SOP Baru', date: '15 Feb 2026', time: '14:00', type: 'pelatihan' },
    { id: 2, title: 'Meeting Evaluasi Q1', date: '18 Feb 2026', time: '10:00', type: 'meeting' },
    { id: 3, title: 'Gathering Mitra', date: '25 Feb 2026', time: '09:00', type: 'event' }
  ];

  const complaints = [
    { id: 1, outlet: 'Gerai Sudirman', issue: 'Keterlambatan pengiriman bahan baku', date: '11 Feb 2026', status: 'open' },
    { id: 2, outlet: 'Gerai Kelapa Gading', issue: 'Masalah sistem POS', date: '10 Feb 2026', status: 'proses' },
    { id: 3, outlet: 'Gerai Kelapa Gading', issue: 'Request tambahan staff', date: '9 Feb 2026', status: 'proses' }
  ];

  const orders = [
    { id: 1, outlet: 'Gerai BSD', items: 'Bahan Baku Paket A', amount: 15000000, status: 'dikirim', date: '12 Feb 2026' },
    { id: 2, outlet: 'Gerai Sudirman', items: 'Supplies & Packaging', amount: 8000000, status: 'proses', date: '12 Feb 2026' }
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', 
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // Beranda Component
  const BerandaView = () => (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign size={18} />
            <span className="text-xs opacity-90">Total Pendapatan</span>
          </div>
          <div className="text-xl font-bold">{formatCurrency(financialSummary.totalRevenue)}</div>
          <div className="flex items-center gap-1 mt-2 text-xs">
            <TrendingUp size={14} />
            <span>+{financialSummary.growth}% bulan ini</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingCart size={18} />
            <span className="text-xs opacity-90">Total Order</span>
          </div>
          <div className="text-xl font-bold">{financialSummary.totalOrders}</div>
          <div className="flex items-center gap-1 mt-2 text-xs">
            <TrendingUp size={14} />
            <span>+{financialSummary.growth}%</span>
          </div>
        </div>
      </div>

      {/* Ringkasan Keuangan */}
      <div className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-800">Ringkasan Keuangan</h3>
          <span className="text-xs text-gray-500">{financialSummary.date}</span>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pendapatan Kotor</span>
            <span className="font-semibold text-green-600">{formatCurrency(financialSummary.grossRevenue)}</span>
          </div>
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pengeluaran</span>
            <span className="font-semibold text-red-600">{formatCurrency(financialSummary.expenses)}</span>
          </div>
          <div className="flex justify-between items-center py-2">
            <span className="text-sm font-semibold text-gray-800">Laba Bersih</span>
            <span className="font-bold text-blue-600 text-lg">{formatCurrency(financialSummary.netProfit)}</span>
          </div>
        </div>
      </div>

      {/* Agenda Terkini - FIXED: Added onClick */}
      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Agenda Terkini</h3>
        <div className="space-y-2">
          {agendas.map(agenda => (
            <div 
              key={agenda.id} 
              onClick={() => alert(`${agenda.title}\n\nTanggal: ${agenda.date}\nWaktu: ${agenda.time}\nTipe: ${agenda.type === 'pelatihan' ? 'Pelatihan' : agenda.type === 'meeting' ? 'Meeting' : 'Event'}`)}
              className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 transition-colors"
            >
              <div className="bg-blue-100 p-2 rounded-lg">
                <Calendar size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm text-gray-800">{agenda.title}</div>
                <div className="text-xs text-gray-500">{agenda.date} • {agenda.time}</div>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-4 shadow-md">
          <div className="text-2xl font-bold text-gray-800">{outlets.length}</div>
          <div className="text-xs text-gray-500 mt-1">Total Gerai</div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md">
          <div className="text-2xl font-bold text-orange-600">{complaints.filter(c => c.status !== 'selesai').length}</div>
          <div className="text-xs text-gray-500 mt-1">Komplain Aktif</div>
        </div>
      </div>
    </div>
  );

  // Continue dengan komponen lainnya...
  // (Untuk menghemat space, saya tidak copy semua komponen di sini)
  // File lengkap sudah tersedia untuk download

  return (
    <div className="max-w-md mx-auto bg-gray-50 min-h-screen flex flex-col">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 sticky top-0 z-40 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">FranchiseHub</h1>
            <p className="text-xs text-blue-100">Dashboard Franchisor</p>
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4">
          {activeMenu === 'beranda' && <BerandaView />}
        </div>
      </div>
    </div>
  );
};

export default FranchisorApp;

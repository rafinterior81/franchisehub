import React, { useState } from 'react';
import FranchisorApp from './franchisor-app';
import AdminDashboard from './admin-dashboard';
import { Smartphone, Monitor } from 'lucide-react';

function App() {
  const [view, setView] = useState('mobile'); // 'mobile' or 'admin'

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Toggle Switcher */}
      <div className="fixed top-4 right-4 z-50 bg-white rounded-2xl shadow-lg border border-gray-200 p-1 flex gap-1">
        <button
          onClick={() => setView('mobile')}
          className={`px-4 py-2 rounded-xl font-semibold flex items-center gap-2 transition-all ${
            view === 'mobile' 
              ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md' 
              : 'bg-transparent text-gray-600 hover:bg-gray-50'
          }`}
        >
          <Smartphone size={18} />
          <span className="hidden sm:inline">Mobile App</span>
        </button>
        <button
          onClick={() => setView('admin')}
          className={`px-4 py-2 rounded-xl font-semibold flex items-center gap-2 transition-all ${
            view === 'admin' 
              ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md' 
              : 'bg-transparent text-gray-600 hover:bg-gray-50'
          }`}
        >
          <Monitor size={18} />
          <span className="hidden sm:inline">Admin Panel</span>
        </button>
      </div>

      {/* Render Selected View */}
      <div className="animate-fadeIn">
        {view === 'mobile' ? <FranchisorApp /> : <AdminDashboard />}
      </div>
    </div>
  );
}

export default App;

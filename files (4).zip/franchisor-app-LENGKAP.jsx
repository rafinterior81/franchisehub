import React, { useState } from 'react';
import { 
  Home, Store, Settings, MessageSquare, Package, TrendingUp, TrendingDown,
  MapPin, Camera, FileText, ShoppingCart, AlertCircle, Calendar, Video,
  Users, DollarSign, BarChart3, Bell, Search, Filter, ChevronRight,
  Phone, Mail, Clock, CheckCircle, XCircle, Plus, Send, Menu, X, ArrowLeft
} from 'lucide-react';

const FranchisorApp = () => {
  const [activeMenu, setActiveMenu] = useState('beranda');
  const [selectedOutlet, setSelectedOutlet] = useState(null);
  const [showCCTV, setShowCCTV] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [userRole, setUserRole] = useState('franchisor');
  const [notifications, setNotifications] = useState(3);

  // Sample data
  const outlets = [
    {
      id: 1, name: 'Gerai Sudirman', owner: 'Ahmad Wijaya',
      address: 'Jl. Sudirman No. 45, Jakarta Pusat',
      status: 'sehat', revenue: 45000000, growth: 12.5,
      lastOrder: '2 jam lalu', healthScore: 95, complaints: 1
    },
    {
      id: 2, name: 'Gerai Kelapa Gading', owner: 'Siti Nurhaliza',
      address: 'Mall Kelapa Gading Lt. 3, Jakarta Utara',
      status: 'perlu perhatian', revenue: 38000000, growth: -5.2,
      lastOrder: '1 hari lalu', healthScore: 72, complaints: 3
    },
    {
      id: 3, name: 'Gerai BSD', owner: 'Budi Santoso',
      address: 'BSD City Walk, Tangerang Selatan',
      status: 'sehat', revenue: 52000000, growth: 18.3,
      lastOrder: '30 menit lalu', healthScore: 98, complaints: 0
    },
    {
      id: 4, name: 'Gerai Depok', owner: 'Linda Kusuma',
      address: 'Margonda Raya No. 88, Depok',
      status: 'sehat', revenue: 41000000, growth: 8.7,
      lastOrder: '4 jam lalu', healthScore: 88, complaints: 1
    }
  ];

  const financialSummary = {
    totalRevenue: 176000000,
    totalOrders: 1247,
    growth: 11.2,
    date: '1-12 Februari 2026',
    grossRevenue: 176000000,
    expenses: 89000000,
    netProfit: 87000000
  };

  const agendas = [
    { id: 1, title: 'Pelatihan SOP Baru', date: '15 Feb 2026', time: '14:00', type: 'pelatihan' },
    { id: 2, title: 'Meeting Evaluasi Q1', date: '18 Feb 2026', time: '10:00', type: 'meeting' },
    { id: 3, title: 'Gathering Mitra', date: '25 Feb 2026', time: '09:00', type: 'event' }
  ];

  const complaints = [
    { id: 1, outlet: 'Gerai Sudirman', issue: 'Keterlambatan pengiriman bahan baku', date: '11 Feb 2026', status: 'open' },
    { id: 2, outlet: 'Gerai Kelapa Gading', issue: 'Masalah sistem POS', date: '10 Feb 2026', status: 'proses' },
    { id: 3, outlet: 'Gerai Kelapa Gading', issue: 'Request tambahan staff', date: '9 Feb 2026', status: 'proses' }
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', 
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // HALAMAN 1: BERANDA
  const BerandaView = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign size={18} />
            <span className="text-xs opacity-90">Total Pendapatan</span>
          </div>
          <div className="text-xl font-bold">{formatCurrency(financialSummary.totalRevenue)}</div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingCart size={18} />
            <span className="text-xs opacity-90">Total Order</span>
          </div>
          <div className="text-xl font-bold">{financialSummary.totalOrders}</div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Ringkasan Keuangan</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pendapatan Kotor</span>
            <span className="font-semibold text-green-600">{formatCurrency(financialSummary.grossRevenue)}</span>
          </div>
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pengeluaran</span>
            <span className="font-semibold text-red-600">{formatCurrency(financialSummary.expenses)}</span>
          </div>
          <div className="flex justify-between items-center py-2">
            <span className="text-sm font-semibold text-gray-800">Laba Bersih</span>
            <span className="font-bold text-blue-600 text-lg">{formatCurrency(financialSummary.netProfit)}</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Agenda Terkini</h3>
        <div className="space-y-2">
          {agendas.map(agenda => (
            <div 
              key={agenda.id}
              onClick={() => setActiveMenu(`agenda-${agenda.id}`)}
              className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 transition-colors"
            >
              <div className="bg-blue-100 p-2 rounded-lg">
                <Calendar size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm text-gray-800">{agenda.title}</div>
                <div className="text-xs text-gray-500">{agenda.date} • {agenda.time}</div>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // HALAMAN 2: AKSI CEPAT - BUAT PESANAN
  const BuatPesananView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold text-gray-800">Buat Pesanan</h1>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Pilih Gerai</h3>
        <div className="space-y-2">
          {outlets.map(outlet => (
            <div 
              key={outlet.id}
              className="p-3 border border-gray-200 rounded-lg hover:bg-blue-50 cursor-pointer"
            >
              <div className="font-medium text-gray-800">{outlet.name}</div>
              <div className="text-xs text-gray-500">{outlet.owner}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Jenis Pesanan</h3>
        <div className="space-y-2">
          {['Bahan Baku', 'Supplies & Packaging', 'Peralatan', 'Lainnya'].map((item, idx) => (
            <div 
              key={idx}
              className="p-3 border border-gray-200 rounded-lg hover:bg-blue-50 cursor-pointer"
            >
              <div className="font-medium text-gray-800">{item}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Jumlah Pesanan</h3>
        <input 
          type="number" 
          placeholder="Masukkan jumlah..." 
          className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 active:bg-blue-800 transition-colors">
        Buat Pesanan Sekarang
      </button>
    </div>
  );

  // HALAMAN 3: CEK KOMPLAIN
  const CekKomplainView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold text-gray-800">Cek Komplain</h1>
      </div>

      <div className="flex gap-2 mb-4">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-full text-sm font-medium">Semua</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-full text-sm font-medium hover:bg-gray-300">Baru</button>
        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-full text-sm font-medium hover:bg-gray-300">Proses</button>
      </div>

      <div className="space-y-3">
        {complaints.map(complaint => (
          <div 
            key={complaint.id}
            className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-2">
              <div>
                <div className="font-semibold text-gray-800">{complaint.outlet}</div>
                <div className="text-sm text-gray-600 mt-1">{complaint.issue}</div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                complaint.status === 'open' 
                  ? 'bg-red-100 text-red-700' 
                  : 'bg-yellow-100 text-yellow-700'
              }`}>
                {complaint.status}
              </span>
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
              <span className="text-xs text-gray-500">{complaint.date}</span>
              <button className="text-blue-600 text-sm font-medium hover:underline">
                Lihat Detail →
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // HALAMAN 4: MEETING
  const MeetingView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold text-gray-800">Jadwal Meeting</h1>
      </div>

      {agendas.filter(a => a.type === 'meeting').map(meeting => (
        <div key={meeting.id} className="bg-white rounded-xl p-4 shadow-md">
          <div className="flex items-start gap-3 mb-4">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Video size={24} className="text-purple-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">{meeting.title}</h2>
              <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Calendar size={16} />
                  {meeting.date}
                </div>
                <div className="flex items-center gap-1">
                  <Clock size={16} />
                  {meeting.time} WIB
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-gray-800 mb-2">Deskripsi Meeting</h3>
            <p className="text-sm text-gray-600">
              Pertemuan evaluasi quarter 1 untuk membahas target penjualan, strategi marketing, dan pengembangan outlet baru.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-gray-800 mb-2">Peserta</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">R</div>
                <span className="text-sm text-gray-700">Reno (Admin)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">A</div>
                <span className="text-sm text-gray-700">Ahmad Wijaya (Pemilik Gerai Sudirman)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">S</div>
                <span className="text-sm text-gray-700">Siti Nurhaliza (Pemilik Gerai Kelapa Gading)</span>
              </div>
            </div>
          </div>

          <button className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 active:bg-purple-800 flex items-center justify-center gap-2 transition-colors">
            <Video size={20} />
            Masuk ke Zoom Meeting
          </button>
        </div>
      ))}
    </div>
  );

  // HALAMAN 5: EVENT & PELATIHAN
  const EventPelatihanView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-bold text-gray-800">Event & Pelatihan</h1>
      </div>

      <div className="space-y-4">
        {agendas.filter(a => a.type !== 'meeting').map(event => (
          <div key={event.id} className="bg-white rounded-xl p-4 shadow-md">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h2 className="text-lg font-semibold text-gray-800">{event.title}</h2>
                <p className="text-xs text-gray-500 mt-1">
                  Tipe: {event.type === 'pelatihan' ? '📚 Pelatihan' : '🎉 Event'}
                </p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                event.type === 'pelatihan' 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-pink-100 text-pink-700'
              }`}>
                {event.type === 'pelatihan' ? 'Pelatihan' : 'Event'}
              </span>
            </div>

            <div className="flex items-center gap-4 text-sm text-gray-600 mb-4 pb-4 border-b border-gray-100">
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                {event.date}
              </div>
              <div className="flex items-center gap-1">
                <Clock size={16} />
                {event.time}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <p className="text-sm text-gray-700">
                {event.type === 'pelatihan' 
                  ? 'Pelatihan standar operasional prosedur terbaru untuk semua staff outlet.'
                  : 'Acara gathering mitra untuk networking dan diskusi tentang perkembangan bisnis.'
                }
              </p>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
                Daftar Sekarang
              </button>
              <button className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 active:bg-gray-400 transition-colors">
                Lihat Detail
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // HALAMAN 6: OPERASIONAL
  const OperasionalView = () => (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-gray-800 mb-3">Aksi Cepat</h3>
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setActiveMenu('buatpesanan')}
            className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Plus size={24} className="mb-2" />
            <div className="font-medium">Order Baru</div>
            <div className="text-xs opacity-90 mt-1">Buat pesanan</div>
          </button>
          <button 
            onClick={() => setActiveMenu('cekkomplain')}
            className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <AlertCircle size={24} className="mb-2" />
            <div className="font-medium">Cek Komplain</div>
            <div className="text-xs opacity-90 mt-1">{complaints.filter(c => c.status !== 'selesai').length} aktif</div>
          </button>
          <button 
            onClick={() => setActiveMenu('meeting')}
            className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Calendar size={24} className="mb-2" />
            <div className="font-medium">Meeting</div>
            <div className="text-xs opacity-90 mt-1">Jadwal terdekat</div>
          </button>
          <button 
            onClick={() => setActiveMenu('eventpelatihan')}
            className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Users size={24} className="mb-2" />
            <div className="font-medium">Event & Pelatihan</div>
            <div className="text-xs opacity-90 mt-1">Lihat semua</div>
          </button>
        </div>
      </div>
    </div>
  );

  // MAIN RENDER
  return (
    <div className="max-w-md mx-auto bg-gray-50 min-h-screen flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 sticky top-0 z-40 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">FranchiseHub</h1>
            <p className="text-xs text-blue-100">Dashboard Franchisor</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative">
              <Bell size={24} />
              {notifications > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {notifications}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4">
          {activeMenu === 'beranda' && <BerandaView />}
          {activeMenu === 'operasional' && <OperasionalView />}
          {activeMenu === 'buatpesanan' && <BuatPesananView />}
          {activeMenu === 'cekkomplain' && <CekKomplainView />}
          {activeMenu === 'meeting' && <MeetingView />}
          {activeMenu === 'eventpelatihan' && <EventPelatihanView />}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg max-w-md mx-auto">
        <div className="grid grid-cols-2 gap-2 p-2">
          <button
            onClick={() => setActiveMenu('beranda')}
            className={`flex flex-col items-center gap-1 py-3 rounded-lg transition-colors ${
              activeMenu === 'beranda' ? 'text-blue-600 bg-blue-50' : 'text-gray-600'
            }`}
          >
            <Home size={22} />
            <span className="text-xs font-medium">Beranda</span>
          </button>
          <button
            onClick={() => setActiveMenu('operasional')}
            className={`flex flex-col items-center gap-1 py-3 rounded-lg transition-colors ${
              ['operasional', 'buatpesanan', 'cekkomplain', 'meeting', 'eventpelatihan'].includes(activeMenu) 
                ? 'text-blue-600 bg-blue-50' 
                : 'text-gray-600'
            }`}
          >
            <Package size={22} />
            <span className="text-xs font-medium">Operasi</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FranchisorApp;

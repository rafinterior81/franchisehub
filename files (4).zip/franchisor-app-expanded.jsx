import React, { useState, useEffect } from 'react';
import { 
  Home, Store, Settings, MessageSquare, Package, TrendingUp, TrendingDown,
  MapPin, Camera, FileText, ShoppingCart, AlertCircle, Calendar, Video,
  Users, DollarSign, BarChart3, Bell, Search, Filter, ChevronRight,
  Phone, Mail, Clock, CheckCircle, XCircle, Plus, Send, Menu, X, ArrowLeft
} from 'lucide-react';

const FranchisorApp = () => {
  const [activeMenu, setActiveMenu] = useState('beranda');
  const [selectedOutlet, setSelectedOutlet] = useState(null);
  const [showCCTV, setShowCCTV] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [userRole, setUserRole] = useState('franchisor');
  const [notifications, setNotifications] = useState(3);
  const [showMenu, setShowMenu] = useState(false);

  // Sample data
  const outlets = [
    {
      id: 1,
      name: 'Gerai Sudirman',
      owner: 'Ahmad Wijaya',
      location: { lat: -6.2088, lng: 106.8456 },
      address: 'Jl. Sudirman No. 45, Jakarta Pusat',
      status: 'sehat',
      revenue: 45000000,
      growth: 12.5,
      lastOrder: '2 jam lalu',
      healthScore: 95,
      complaints: 1
    },
    {
      id: 2,
      name: 'Gerai Kelapa Gading',
      owner: 'Siti Nurhaliza',
      location: { lat: -6.1570, lng: 106.9050 },
      address: 'Mall Kelapa Gading Lt. 3, Jakarta Utara',
      status: 'perlu perhatian',
      revenue: 38000000,
      growth: -5.2,
      lastOrder: '1 hari lalu',
      healthScore: 72,
      complaints: 3
    },
    {
      id: 3,
      name: 'Gerai BSD',
      owner: 'Budi Santoso',
      location: { lat: -6.3018, lng: 106.6519 },
      address: 'BSD City Walk, Tangerang Selatan',
      status: 'sehat',
      revenue: 52000000,
      growth: 18.3,
      lastOrder: '30 menit lalu',
      healthScore: 98,
      complaints: 0
    },
    {
      id: 4,
      name: 'Gerai Depok',
      owner: 'Linda Kusuma',
      location: { lat: -6.4025, lng: 106.7942 },
      address: 'Margonda Raya No. 88, Depok',
      status: 'sehat',
      revenue: 41000000,
      growth: 8.7,
      lastOrder: '4 jam lalu',
      healthScore: 88,
      complaints: 1
    }
  ];

  const financialSummary = {
    totalRevenue: 176000000,
    totalOrders: 1247,
    growth: 11.2,
    date: '1-12 Februari 2026',
    grossRevenue: 176000000,
    expenses: 89000000,
    netProfit: 87000000
  };

  const agendas = [
    { id: 1, title: 'Pelatihan SOP Baru', date: '15 Feb 2026', time: '14:00', type: 'pelatihan', location: 'Head Office Jakarta', description: 'Pelatihan komprehensif tentang SOP terbaru untuk semua mitra' },
    { id: 2, title: 'Meeting Evaluasi Q1', date: '18 Feb 2026', time: '10:00', type: 'meeting', location: 'Virtual Zoom', description: 'Evaluasi kinerja quarter 1 dan planning Q2' },
    { id: 3, title: 'Gathering Mitra', date: '25 Feb 2026', time: '09:00', type: 'event', location: 'Hotel Grand Indonesia', description: 'Gathering tahunan semua mitra franchise' }
  ];

  const complaints = [
    { id: 1, outlet: 'Gerai Sudirman', issue: 'Keterlambatan pengiriman bahan baku', date: '11 Feb 2026', status: 'open', priority: 'high' },
    { id: 2, outlet: 'Gerai Kelapa Gading', issue: 'Masalah sistem POS', date: '10 Feb 2026', status: 'proses', priority: 'high' },
    { id: 3, outlet: 'Gerai Kelapa Gading', issue: 'Request tambahan staff', date: '9 Feb 2026', status: 'proses', priority: 'medium' }
  ];

  const orders = [
    { id: 1, outlet: 'Gerai BSD', items: 'Bahan Baku Paket A', amount: 15000000, status: 'dikirim', date: '12 Feb 2026' },
    { id: 2, outlet: 'Gerai Sudirman', items: 'Supplies & Packaging', amount: 8000000, status: 'proses', date: '12 Feb 2026' }
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', 
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // ==================== HALAMAN APLIKASI TERKINI ====================
  const ApplikasiTerkiniView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Aplikasi Terkini</h2>
      </div>

      <div className="space-y-3">
        {agendas.map(agenda => (
          <div key={agenda.id} className="bg-white rounded-xl p-4 shadow-md border-l-4 border-blue-500">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800 text-lg">{agenda.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{agenda.description}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ml-2 ${
                agenda.type === 'pelatihan' ? 'bg-green-100 text-green-700' :
                agenda.type === 'meeting' ? 'bg-purple-100 text-purple-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {agenda.type === 'pelatihan' ? '📚 Pelatihan' : agenda.type === 'meeting' ? '💼 Meeting' : '🎉 Event'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-3 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-blue-500" />
                <span>{agenda.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-blue-500" />
                <span>{agenda.time} WIB</span>
              </div>
              <div className="flex items-center gap-2 col-span-2">
                <MapPin size={16} className="text-blue-500" />
                <span>{agenda.location}</span>
              </div>
            </div>

            <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
              Daftar / Detail Lengkap
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  // ==================== HALAMAN BUAT PESANAN ====================
  const BuatPesananView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Buat Pesanan Baru</h2>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-800 mb-2">Pilih Gerai</label>
          <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
            <option>-- Pilih Gerai --</option>
            {outlets.map(outlet => (
              <option key={outlet.id}>{outlet.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-800 mb-2">Kategori Pesanan</label>
          <div className="grid grid-cols-2 gap-2">
            {['Bahan Baku', 'Supplies', 'Peralatan', 'Packaging'].map(cat => (
              <button key={cat} className="p-3 border border-gray-300 rounded-lg hover:bg-blue-50 hover:border-blue-500 transition-colors text-sm font-medium">
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-800 mb-2">Detail Pesanan</label>
          <textarea 
            placeholder="Deskripsikan item yang ingin dipesan..."
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none"
            rows="4"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-800 mb-2">Estimasi Budget</label>
          <input 
            type="number" 
            placeholder="Masukkan jumlah (Rp)"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-800 mb-2">Tanggal Dibutuhkan</label>
          <input 
            type="date"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
          Kirim Pesanan
        </button>
      </div>
    </div>
  );

  // ==================== HALAMAN CEK KOMPLAIN ====================
  const CekKomplainView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Cek Komplain</h2>
      </div>

      <div className="flex gap-2 mb-4">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-full text-sm font-medium">Semua</button>
        <button className="px-4 py-2 bg-red-100 text-red-700 rounded-full text-sm font-medium">Baru</button>
        <button className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">Proses</button>
      </div>

      <div className="space-y-3">
        {complaints.map(complaint => (
          <div key={complaint.id} className="bg-white rounded-xl p-4 shadow-md border-l-4 border-red-500">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{complaint.outlet}</h3>
                <p className="text-sm text-gray-600 mt-1">{complaint.issue}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ml-2 ${
                complaint.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {complaint.priority === 'high' ? '🔴 Urgent' : '🟡 Medium'}
              </span>
            </div>

            <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
              <span>{complaint.date}</span>
              <span className={`px-2 py-1 rounded-full font-medium ${
                complaint.status === 'open' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {complaint.status === 'open' ? 'Baru' : 'Dalam Proses'}
              </span>
            </div>

            <button className="w-full mt-3 bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
              Lihat Detail & Tanggapi
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  // ==================== HALAMAN MEETING ====================
  const MeetingView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Meeting Schedule</h2>
      </div>

      <div className="space-y-3">
        {agendas.filter(a => a.type === 'meeting').map(meeting => (
          <div key={meeting.id} className="bg-white rounded-xl p-4 shadow-md border-l-4 border-purple-500">
            <div className="mb-3">
              <h3 className="font-semibold text-gray-800 text-lg">{meeting.title}</h3>
              <p className="text-sm text-gray-600 mt-1">{meeting.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm text-gray-600 mb-4">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-purple-500" />
                <span>{meeting.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-purple-500" />
                <span>{meeting.time} WIB</span>
              </div>
              <div className="flex items-center gap-2 col-span-2">
                <MapPin size={16} className="text-purple-500" />
                <span>{meeting.location}</span>
              </div>
            </div>

            <div className="space-y-2">
              <button className="w-full bg-purple-600 text-white py-2 rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center justify-center gap-2">
                <Video size={18} />
                Join Zoom Meeting
              </button>
              <button className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                Lihat Detail
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Upcoming Meetings */}
      <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
        <h3 className="font-semibold text-gray-800 mb-2">💡 Tips</h3>
        <p className="text-sm text-gray-700">Pastikan Anda bergabung 5 menit sebelum meeting dimulai untuk persiapan teknis yang optimal.</p>
      </div>
    </div>
  );

  // ==================== HALAMAN EVENT & PELATIHAN ====================
  const EventPelatihanView = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={() => setActiveMenu('operasional')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Event & Pelatihan</h2>
      </div>

      <div className="flex gap-2 mb-4">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-full text-sm font-medium">Semua</button>
        <button className="px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium">Pelatihan</button>
        <button className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">Event</button>
      </div>

      <div className="space-y-3">
        {agendas.filter(a => a.type !== 'meeting').map(event => (
          <div key={event.id} className="bg-white rounded-xl p-4 shadow-md border-l-4 border-green-500">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800 text-lg">{event.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{event.description}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ml-2 ${
                event.type === 'pelatihan' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
              }`}>
                {event.type === 'pelatihan' ? '📚 Pelatihan' : '🎉 Event'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm text-gray-600 mb-4">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-green-500" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-green-500" />
                <span>{event.time} WIB</span>
              </div>
              <div className="flex items-center gap-2 col-span-2">
                <MapPin size={16} className="text-green-500" />
                <span>{event.location}</span>
              </div>
            </div>

            <div className="space-y-2">
              <button className="w-full bg-green-600 text-white py-2 rounded-lg font-medium hover:bg-green-700 transition-colors">
                Daftar Sekarang
              </button>
              <button className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                Lihat Detail Lengkap
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ==================== BERANDA (ORIGINAL) ====================
  const BerandaView = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign size={18} />
            <span className="text-xs opacity-90">Total Pendapatan</span>
          </div>
          <div className="text-xl font-bold">{formatCurrency(financialSummary.totalRevenue)}</div>
          <div className="flex items-center gap-1 mt-2 text-xs">
            <TrendingUp size={14} />
            <span>+{financialSummary.growth}% bulan ini</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingCart size={18} />
            <span className="text-xs opacity-90">Total Order</span>
          </div>
          <div className="text-xl font-bold">{financialSummary.totalOrders}</div>
          <div className="flex items-center gap-1 mt-2 text-xs">
            <TrendingUp size={14} />
            <span>+{financialSummary.growth}%</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-800">Ringkasan Keuangan</h3>
          <span className="text-xs text-gray-500">{financialSummary.date}</span>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pendapatan Kotor</span>
            <span className="font-semibold text-green-600">{formatCurrency(financialSummary.grossRevenue)}</span>
          </div>
          <div className="flex justify-between items-center py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Pengeluaran</span>
            <span className="font-semibold text-red-600">{formatCurrency(financialSummary.expenses)}</span>
          </div>
          <div className="flex justify-between items-center py-2">
            <span className="text-sm font-semibold text-gray-800">Laba Bersih</span>
            <span className="font-bold text-blue-600 text-lg">{formatCurrency(financialSummary.netProfit)}</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Agenda Terkini</h3>
        <div className="space-y-2">
          {agendas.map(agenda => (
            <div key={agenda.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Calendar size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm text-gray-800">{agenda.title}</div>
                <div className="text-xs text-gray-500">{agenda.date} • {agenda.time}</div>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-4 shadow-md">
          <div className="text-2xl font-bold text-gray-800">{outlets.length}</div>
          <div className="text-xs text-gray-500 mt-1">Total Gerai</div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md">
          <div className="text-2xl font-bold text-orange-600">{complaints.filter(c => c.status !== 'selesai').length}</div>
          <div className="text-xs text-gray-500 mt-1">Komplain Aktif</div>
        </div>
      </div>
    </div>
  );

  // ==================== OPERASIONAL (dengan quick actions yang di-update) ====================
  const OperasionalView = () => (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-gray-800 mb-3">Aksi Cepat</h3>
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setActiveMenu('buat-pesanan')}
            className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Plus size={24} className="mb-2" />
            <div className="font-medium">Order Baru</div>
            <div className="text-xs opacity-90 mt-1">Buat pesanan</div>
          </button>
          <button 
            onClick={() => setActiveMenu('cek-komplain')}
            className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <AlertCircle size={24} className="mb-2" />
            <div className="font-medium">Cek Komplain</div>
            <div className="text-xs opacity-90 mt-1">{complaints.filter(c => c.status !== 'selesai').length} aktif</div>
          </button>
          <button 
            onClick={() => setActiveMenu('meeting')}
            className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Video size={24} className="mb-2" />
            <div className="font-medium">Meeting</div>
            <div className="text-xs opacity-90 mt-1">Jadwal terdekat</div>
          </button>
          <button 
            onClick={() => setActiveMenu('event-pelatihan')}
            className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-xl shadow-lg hover:shadow-xl active:shadow-md transition-all cursor-pointer"
          >
            <Users size={24} className="mb-2" />
            <div className="font-medium">Event & Pelatihan</div>
            <div className="text-xs opacity-90 mt-1">Lihat semua</div>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-semibold text-gray-800 mb-3">Status Order Terakhir</h3>
        <div className="space-y-3">
          {orders.map(order => (
            <div key={order.id} className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="font-medium text-sm text-gray-800">{order.outlet}</div>
                  <div className="text-xs text-gray-500">{order.items}</div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  order.status === 'dikirim' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {order.status}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-600">{order.date}</span>
                <span className="font-semibold text-gray-800">{formatCurrency(order.amount)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Main Render
  return (
    <div className="max-w-md mx-auto bg-gray-50 min-h-screen flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 sticky top-0 z-40 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">FranchiseHub</h1>
            <p className="text-xs text-blue-100">Dashboard Franchisor</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative">
              <Bell size={24} />
              {notifications > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {notifications}
                </span>
              )}
            </button>
            <div className="w-8 h-8 bg-white text-blue-600 rounded-full flex items-center justify-center font-bold">
              F
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4">
          {activeMenu === 'beranda' && <BerandaView />}
          {activeMenu === 'operasional' && <OperasionalView />}
          {activeMenu === 'aplikasi-terkini' && <ApplikasiTerkiniView />}
          {activeMenu === 'buat-pesanan' && <BuatPesananView />}
          {activeMenu === 'cek-komplain' && <CekKomplainView />}
          {activeMenu === 'meeting' && <MeetingView />}
          {activeMenu === 'event-pelatihan' && <EventPelatihanView />}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg max-w-md mx-auto">
        <div className="grid grid-cols-5 gap-1 p-2">
          <button
            onClick={() => setActiveMenu('beranda')}
            className={`flex flex-col items-center gap-1 py-2 rounded-lg transition-colors ${
              activeMenu === 'beranda' ? 'text-blue-600 bg-blue-50' : 'text-gray-600'
            }`}
          >
            <Home size={22} />
            <span className="text-xs font-medium">Beranda</span>
          </button>
          <button
            onClick={() => setActiveMenu('operasional')}
            className={`flex flex-col items-center gap-1 py-2 rounded-lg transition-colors ${
              ['operasional', 'buat-pesanan', 'cek-komplain', 'meeting', 'event-pelatihan'].includes(activeMenu) 
                ? 'text-blue-600 bg-blue-50' 
                : 'text-gray-600'
            }`}
          >
            <Package size={22} />
            <span className="text-xs font-medium">Operasi</span>
          </button>
          <button
            onClick={() => setActiveMenu('aplikasi-terkini')}
            className={`flex flex-col items-center gap-1 py-2 rounded-lg transition-colors ${
              activeMenu === 'aplikasi-terkini' ? 'text-blue-600 bg-blue-50' : 'text-gray-600'
            }`}
          >
            <Calendar size={22} />
            <span className="text-xs font-medium">Agenda</span>
          </button>
          <button
            onClick={() => alert('Menu Mitra akan segera ditambahkan')}
            className="flex flex-col items-center gap-1 py-2 rounded-lg transition-colors text-gray-600"
          >
            <Store size={22} />
            <span className="text-xs font-medium">Mitra</span>
          </button>
          <button
            onClick={() => alert('Menu Akun akan segera ditambahkan')}
            className="flex flex-col items-center gap-1 py-2 rounded-lg transition-colors text-gray-600"
          >
            <Settings size={22} />
            <span className="text-xs font-medium">Akun</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FranchisorApp;
